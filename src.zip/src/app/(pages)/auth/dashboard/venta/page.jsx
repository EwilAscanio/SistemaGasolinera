import React from "react";

const page = () => {
  return (
    <div className="flex items-center justify-center">Page Venta Gasolina </div>
  );
};

export default page;
